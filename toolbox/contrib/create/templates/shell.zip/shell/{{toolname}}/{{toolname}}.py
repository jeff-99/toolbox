from toolbox.plugin import ExecutablePlugin

class {{toolname|c}}Plugin (ExecutablePlugin):

    name = "{{toolname}}"
    description = "{{toolname|c}} is a plugin I created, yay!"
    executable = "{{executable}}"
    args = {{args|pylist}}

