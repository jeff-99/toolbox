from toolbox.plugin import ToolboxPlugin

class {{toolname|c}}Plugin (ToolboxPlugin):

    name = "{{toolname}}"
    description = "{{toolname|c}} is a plugin I created, yay!"

    def prepare_parser(self, parser):
        pass

    def execute(self,args):
        pass

