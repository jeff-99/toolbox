from .{{toolname}} import {{toolname|c}}Plugin

Plugin = {{toolname|c}}Plugin()